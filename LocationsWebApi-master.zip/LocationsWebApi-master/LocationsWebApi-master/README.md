# LocationsWebApi

## You can see the site deployed in Azure here: https://locations-api-example.azurewebsites.net/
